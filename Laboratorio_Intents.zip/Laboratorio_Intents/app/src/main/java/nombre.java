public class nombre {
}
